"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Lightbulb,
  MessageSquare,
  Save,
  Share,
  ThumbsUp,
  Sparkles,
  CheckCircle,
  BarChart,
  Users,
  Target,
  FileText,
} from "lucide-react"
import { motion } from "framer-motion"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function IdeaDevelopmentPage() {
  const [idea, setIdea] = useState("")
  const [domain, setDomain] = useState("")
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([])
  const [communityFeedback, setCommunityFeedback] = useState<
    { id: number; user: string; comment: string; likes: number; avatar: string }[]
  >([
    {
      id: 1,
      user: "Jane Smith",
      comment: "This is a great idea! Have you considered expanding to international markets?",
      likes: 3,
      avatar: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      user: "John Doe",
      comment: "I think you should focus on the mobile app first before expanding to other platforms.",
      likes: 5,
      avatar: "/placeholder.svg?height=40&width=40",
    },
  ])
  const [isLoading, setIsLoading] = useState(false)
  const [activeTab, setActiveTab] = useState("ai")

  const handleGenerateAISuggestions = () => {
    setIsLoading(true)
    // Simulate AI response
    setTimeout(() => {
      setAiSuggestions([
        "Consider focusing on a specific niche within your target market to establish a strong initial user base.",
        "You might want to explore partnerships with existing platforms to leverage their user base.",
        "Think about how you can incorporate a freemium model to attract users while monetizing premium features.",
        "Consider adding a feature that allows users to track their progress and milestones.",
      ])
      setIsLoading(false)
    }, 1500)
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  }

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  }

  return (
    <div className="container py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4"
      >
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Idea Development</h1>
          <p className="text-muted-foreground">
            Refine your startup concept with AI assistance and community feedback.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="button-hover border-2">
            <Save className="mr-2 h-4 w-4" /> Save Draft
          </Button>
          <Button className="button-hover bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
            <Share className="mr-2 h-4 w-4" /> Share for Feedback
          </Button>
        </div>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="lg:col-span-2"
        >
          <Card className="card-hover border-2 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 opacity-100 transition-opacity duration-300" />
            <CardHeader className="relative">
              <CardTitle>Develop Your Idea</CardTitle>
              <CardDescription>Describe your startup idea in detail</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 relative">
              <div className="space-y-2">
                <Label htmlFor="title">Idea Title</Label>
                <Input
                  id="title"
                  placeholder="Give your idea a catchy title"
                  className="border-2 focus:border-primary/50 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="domain">Domain</Label>
                <Select value={domain} onValueChange={setDomain}>
                  <SelectTrigger className="border-2 focus:border-primary/50 transition-colors">
                    <SelectValue placeholder="Select a domain" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="tech">Technology</SelectItem>
                    <SelectItem value="health">Healthcare</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="ecommerce">E-Commerce</SelectItem>
                    <SelectItem value="food">Food & Beverage</SelectItem>
                    <SelectItem value="travel">Travel</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your startup idea in detail..."
                  className="min-h-[200px] border-2 focus:border-primary/50 transition-colors"
                  value={idea}
                  onChange={(e) => setIdea(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="problem">Problem Statement</Label>
                <Textarea
                  id="problem"
                  placeholder="What problem does your startup solve?"
                  className="min-h-[100px] border-2 focus:border-primary/50 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="solution">Solution</Label>
                <Textarea
                  id="solution"
                  placeholder="How does your startup solve this problem?"
                  className="min-h-[100px] border-2 focus:border-primary/50 transition-colors"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="target">Target Market</Label>
                <Textarea
                  id="target"
                  placeholder="Who is your target audience?"
                  className="min-h-[100px] border-2 focus:border-primary/50 transition-colors"
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between relative">
              <Button variant="outline" className="button-hover border-2">
                Clear
              </Button>
              <Button
                onClick={handleGenerateAISuggestions}
                disabled={!idea || isLoading}
                className={`button-hover ${isLoading ? "bg-muted" : "bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"}`}
              >
                {isLoading ? (
                  <>
                    <Sparkles className="mr-2 h-4 w-4 animate-spin-slow" /> Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 h-4 w-4" /> Get AI Suggestions
                  </>
                )}
              </Button>
            </CardFooter>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <Tabs defaultValue="ai" className="w-full" onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 mb-4 p-1 bg-muted/50 backdrop-blur-sm">
              <TabsTrigger
                value="ai"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-primary data-[state=active]:text-primary-foreground transition-all duration-300"
              >
                AI Suggestions
              </TabsTrigger>
              <TabsTrigger
                value="community"
                className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-primary/80 data-[state=active]:to-primary data-[state=active]:text-primary-foreground transition-all duration-300"
              >
                Community
              </TabsTrigger>
            </TabsList>
            <TabsContent value="ai" className="mt-0">
              <Card className="card-hover border-2 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 opacity-100 transition-opacity duration-300" />
                <CardHeader className="relative">
                  <CardTitle className="flex items-center gap-2">
                    <Lightbulb className="h-5 w-5 text-primary" />
                    AI-Powered Analysis
                  </CardTitle>
                  <CardDescription>
                    Get comprehensive AI-powered insights to validate and improve your idea
                  </CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  <Tabs defaultValue="market" className="w-full">
                    {/* Scrollable tabs container */}
                    <div className="overflow-x-auto pb-2 mb-2">
                      <TabsList className="inline-flex min-w-full">
                        <TabsTrigger value="market" className="flex items-center gap-1">
                          <BarChart className="h-4 w-4" /> Market Analysis
                        </TabsTrigger>
                        <TabsTrigger value="competitor" className="flex items-center gap-1">
                          <Users className="h-4 w-4" /> Competitor Analysis
                        </TabsTrigger>
                        <TabsTrigger value="gap" className="flex items-center gap-1">
                          <Target className="h-4 w-4" /> Gap Identification
                        </TabsTrigger>
                        <TabsTrigger value="discovery" className="flex items-center gap-1">
                          <FileText className="h-4 w-4" /> Customer Discovery
                        </TabsTrigger>
                      </TabsList>
                    </div>

                    <TabsContent value="market" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="text-sm font-medium mb-2 flex items-center">
                          <Sparkles className="h-4 w-4 mr-2 text-primary" />
                          AI-powered Market Analysis
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Our AI analyzes market trends, consumer behavior, and industry data to identify potential
                          demand for your idea.
                        </p>
                        {aiSuggestions.length > 0 ? (
                          <motion.ul
                            variants={container}
                            initial="hidden"
                            animate={activeTab === "ai" ? "show" : "hidden"}
                            className="space-y-3"
                          >
                            <motion.li
                              variants={item}
                              className="bg-background p-3 rounded-md text-sm border-l-2 border-primary"
                            >
                              <span className="font-medium">Market Size:</span> The global market for sustainable supply
                              chains is projected to reach $15.3B by 2025 with a CAGR of 7.5%.
                            </motion.li>
                            <motion.li
                              variants={item}
                              className="bg-background p-3 rounded-md text-sm border-l-2 border-primary"
                            >
                              <span className="font-medium">Target Segments:</span> Mid-size manufacturers (100-500
                              employees) show the highest adoption potential at 68%.
                            </motion.li>
                            <motion.li
                              variants={item}
                              className="bg-background p-3 rounded-md text-sm border-l-2 border-primary"
                            >
                              <span className="font-medium">Regional Demand:</span> Highest growth potential in European
                              markets due to stringent regulatory requirements.
                            </motion.li>
                          </motion.ul>
                        ) : (
                          <div className="text-center py-6">
                            <p className="text-muted-foreground">Describe your idea to generate market analysis</p>
                          </div>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full mt-3 button-hover"
                          disabled={!idea}
                          onClick={handleGenerateAISuggestions}
                        >
                          {isLoading ? (
                            <>
                              <Sparkles className="mr-2 h-4 w-4 animate-spin-slow" /> Analyzing Market...
                            </>
                          ) : (
                            <>
                              <Sparkles className="mr-2 h-4 w-4" /> Generate Market Analysis
                            </>
                          )}
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="competitor" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="text-sm font-medium mb-2 flex items-center">
                          <Sparkles className="h-4 w-4 mr-2 text-primary" />
                          Competitor Analysis
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Our AI identifies key competitors, their strengths, weaknesses, and market positioning to help
                          you differentiate.
                        </p>
                        <div className="space-y-3">
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Top Competitors:</span> AI will identify direct and indirect
                            competitors in your space.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Competitive Advantages:</span> Analysis of unique selling
                            propositions and market positioning.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Market Share Distribution:</span> Visual breakdown of market
                            share among key players.
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full mt-3 button-hover" disabled={!idea}>
                          <Sparkles className="mr-2 h-4 w-4" /> Generate Competitor Analysis
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="gap" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="text-sm font-medium mb-2 flex items-center">
                          <Sparkles className="h-4 w-4 mr-2 text-primary" />
                          Market Gap Identification
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Our AI identifies underserved market segments and unmet customer needs your idea could
                          address.
                        </p>
                        <div className="space-y-3">
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Opportunity Spaces:</span> Visualization of market gaps and
                            opportunity areas.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Unmet Needs:</span> Analysis of customer pain points not
                            addressed by existing solutions.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Positioning Strategy:</span> Recommendations for positioning
                            your solution in the market.
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full mt-3 button-hover" disabled={!idea}>
                          <Sparkles className="mr-2 h-4 w-4" /> Identify Market Gaps
                        </Button>
                      </div>
                    </TabsContent>

                    <TabsContent value="discovery" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="text-sm font-medium mb-2 flex items-center">
                          <Sparkles className="h-4 w-4 mr-2 text-primary" />
                          Customer Discovery Framework
                        </h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          Our AI generates structured interview frameworks to validate your idea with potential
                          customers.
                        </p>
                        <div className="space-y-3">
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Interview Questions:</span> Tailored questions to validate
                            problem, solution, and willingness to pay.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Target Personas:</span> Identification of key customer
                            personas to interview.
                          </div>
                          <div className="bg-background p-3 rounded-md text-sm border-l-2 border-primary">
                            <span className="font-medium">Validation Metrics:</span> Framework for measuring and
                            analyzing customer feedback.
                          </div>
                        </div>
                        <Button variant="outline" size="sm" className="w-full mt-3 button-hover" disabled={!idea}>
                          <Sparkles className="mr-2 h-4 w-4" /> Generate Interview Framework
                        </Button>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="community" className="mt-0">
              <Card className="card-hover border-2 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-secondary/5 to-accent/5 opacity-100 transition-opacity duration-300" />
                <CardHeader className="relative">
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-primary" />
                    Community Feedback
                  </CardTitle>
                  <CardDescription>Get feedback from fellow entrepreneurs and industry experts</CardDescription>
                </CardHeader>
                <CardContent className="relative">
                  <Tabs defaultValue="feedback" className="w-full">
                    {/* Scrollable tabs container */}
                    <div className="overflow-x-auto pb-2 mb-2">
                      <TabsList className="inline-flex min-w-full">
                        <TabsTrigger value="feedback" className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4" /> User Feedback
                        </TabsTrigger>
                        <TabsTrigger value="experts" className="flex items-center gap-1">
                          <Users className="h-4 w-4" /> Expert Analysis
                        </TabsTrigger>
                        <TabsTrigger value="insights" className="flex items-center gap-1">
                          <Lightbulb className="h-4 w-4" /> Collective Insights
                        </TabsTrigger>
                      </TabsList>
                    </div>

                    <TabsContent value="feedback" className="space-y-4">
                      <motion.div
                        variants={container}
                        initial="hidden"
                        animate={activeTab === "community" ? "show" : "hidden"}
                        className="space-y-4"
                      >
                        {communityFeedback.map((feedback) => (
                          <motion.div
                            key={feedback.id}
                            variants={item}
                            className="border-2 rounded-md p-4 hover:border-primary/20 transition-colors duration-300"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <div className="flex items-center gap-2">
                                <Avatar>
                                  <AvatarImage src={feedback.avatar || "/placeholder.svg"} alt={feedback.user} />
                                  <AvatarFallback>{feedback.user.charAt(0)}</AvatarFallback>
                                </Avatar>
                                <div className="font-medium">{feedback.user}</div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 px-2 hover:bg-primary/10 hover:text-primary transition-colors"
                              >
                                <ThumbsUp className="h-4 w-4 mr-1" />
                                {feedback.likes}
                              </Button>
                            </div>
                            <p className="text-sm text-muted-foreground">{feedback.comment}</p>
                          </motion.div>
                        ))}
                      </motion.div>
                    </TabsContent>

                    <TabsContent value="experts" className="space-y-4">
                      <div className="border-2 rounded-md p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Dr. Sarah Johnson" />
                            <AvatarFallback>SJ</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">Dr. Sarah Johnson</div>
                            <div className="text-xs text-muted-foreground">
                              Product Strategy Expert • Former Google PM
                            </div>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          "Your idea has strong potential, but I'd recommend focusing on a specific vertical first
                          rather than trying to serve all industries. This will help you refine your value proposition
                          and go-to-market strategy."
                        </p>
                        <div className="flex justify-between items-center">
                          <Badge variant="outline">Expert Insight</Badge>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <MessageSquare className="h-4 w-4 mr-1" /> Reply
                          </Button>
                        </div>
                      </div>

                      <div className="border-2 rounded-md p-4">
                        <div className="flex items-center gap-3 mb-3">
                          <Avatar>
                            <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Michael Chen" />
                            <AvatarFallback>MC</AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">Michael Chen</div>
                            <div className="text-xs text-muted-foreground">Industry Analyst • Tech Ventures</div>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">
                          "I've seen similar solutions in the market. Your key differentiator should be the integration
                          with existing workflows. Consider partnerships with established platforms to accelerate
                          adoption."
                        </p>
                        <div className="flex justify-between items-center">
                          <Badge variant="outline">Expert Insight</Badge>
                          <Button variant="ghost" size="sm" className="h-8 px-2">
                            <MessageSquare className="h-4 w-4 mr-1" /> Reply
                          </Button>
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="insights" className="space-y-4">
                      <div className="bg-muted/50 p-4 rounded-md">
                        <h3 className="text-sm font-medium mb-3">Collective Feedback Analysis</h3>
                        <div className="space-y-3">
                          <div className="bg-background p-3 rounded-md text-sm">
                            <div className="flex justify-between mb-1">
                              <span className="font-medium">Problem Validation</span>
                              <span className="text-primary font-medium">87%</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "87%" }}></div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              87% of community members agree this is a significant problem worth solving
                            </p>
                          </div>

                          <div className="bg-background p-3 rounded-md text-sm">
                            <div className="flex justify-between mb-1">
                              <span className="font-medium">Solution Fit</span>
                              <span className="text-primary font-medium">72%</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "72%" }}></div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              72% believe your proposed solution effectively addresses the problem
                            </p>
                          </div>

                          <div className="bg-background p-3 rounded-md text-sm">
                            <div className="flex justify-between mb-1">
                              <span className="font-medium">Market Potential</span>
                              <span className="text-primary font-medium">91%</span>
                            </div>
                            <div className="w-full bg-muted rounded-full h-2">
                              <div className="bg-primary h-2 rounded-full" style={{ width: "91%" }}></div>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              91% see significant market potential for this idea
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="bg-background p-4 rounded-md border-2">
                        <h3 className="text-sm font-medium mb-2">Key Recommendations</h3>
                        <ul className="space-y-2 text-sm text-muted-foreground">
                          <li className="flex items-start gap-2">
                            <div className="rounded-full bg-primary/10 p-1 mt-0.5">
                              <CheckCircle className="h-3 w-3 text-primary" />
                            </div>
                            <span>Focus on a specific industry vertical for initial launch</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <div className="rounded-full bg-primary/10 p-1 mt-0.5">
                              <CheckCircle className="h-3 w-3 text-primary" />
                            </div>
                            <span>Develop a freemium model to accelerate user acquisition</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <div className="rounded-full bg-primary/10 p-1 mt-0.5">
                              <CheckCircle className="h-3 w-3 text-primary" />
                            </div>
                            <span>Consider partnerships with existing platforms for integration</span>
                          </li>
                        </ul>
                      </div>
                    </TabsContent>
                  </Tabs>
                </CardContent>
                <CardFooter className="flex-col gap-4 relative">
                  <Textarea
                    placeholder="Add your comment or question about this idea..."
                    className="min-h-[80px] border-2 focus:border-primary/50 transition-colors"
                  />
                  <Button className="w-full button-hover bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90">
                    <MessageSquare className="mr-2 h-4 w-4" /> Post Comment
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </div>
  )
}
